/* =========================================================
   BITEAURA SIGNUP INTERACTIONS
========================================================= */


/* =========================
   SHOW / HIDE PASSWORD
========================= */

document.querySelectorAll(".password-toggle").forEach(function(button) {

    button.addEventListener("click", function() {

        const targetId = this.getAttribute("data-target");

        const input = document.getElementById(targetId);

        if (!input) return;


        if (input.type === "password") {

            input.type = "text";

            this.textContent = "🙈";

        } else {

            input.type = "password";

            this.textContent = "👁️";

        }

    });

});


/* =========================
   PASSWORD STRENGTH
========================= */

const password1 = document.getElementById("password1");

const strengthBar = document.getElementById("strengthBar");

const strengthText = document.getElementById("strengthText");


if (password1) {

    password1.addEventListener("input", function() {

        const password = this.value;

        let strength = 0;


        if (password.length >= 6) {

            strength++;

        }


        if (/[A-Z]/.test(password)) {

            strength++;

        }


        if (/[0-9]/.test(password)) {

            strength++;

        }


        if (/[^A-Za-z0-9]/.test(password)) {

            strength++;

        }


        strengthBar.className = "strength-bar";


        if (password.length === 0) {

            strengthText.textContent = "";

        }

        else if (strength === 1) {

            strengthBar.classList.add("weak");

            strengthText.textContent = "Weak password";

        }

        else if (strength === 2) {

            strengthBar.classList.add("medium");

            strengthText.textContent = "Medium password";

        }

        else if (strength === 3) {

            strengthBar.classList.add("good");

            strengthText.textContent = "Good password";

        }

        else {

            strengthBar.classList.add("strong");

            strengthText.textContent = "Strong password ✓";

        }

    });

}


/* =========================
   PASSWORD MATCH
========================= */

const password2 = document.getElementById("password2");

const passwordMatch = document.getElementById("passwordMatch");


function checkPasswordMatch() {

    if (!password1 || !password2 || !passwordMatch) {

        return;

    }


    if (password2.value === "") {

        passwordMatch.textContent = "";

        passwordMatch.className = "password-match";

        return;

    }


    if (password1.value === password2.value) {

        passwordMatch.textContent =
            "✓ Passwords match";

        passwordMatch.className =
            "password-match success";

    } else {

        passwordMatch.textContent =
            "✕ Passwords do not match";

        passwordMatch.className =
            "password-match error";

    }

}


if (password1) {

    password1.addEventListener(
        "input",
        checkPasswordMatch
    );

}


if (password2) {

    password2.addEventListener(
        "input",
        checkPasswordMatch
    );


}


/* =========================
   INPUT ANIMATION
========================= */

document.querySelectorAll(".signup-input-wrapper input")
.forEach(function(input) {

    input.addEventListener("focus", function() {

        this.closest(".signup-input-wrapper")
            .classList.add("active");

    });


    input.addEventListener("blur", function() {

        this.closest(".signup-input-wrapper")
            .classList.remove("active");

    });

});


/* =========================
   FORM SUBMIT
========================= */

const registerForm =
    document.getElementById("registerForm");


if (registerForm) {

    registerForm.addEventListener("submit", function(event) {

        if (
            password1 &&
            password2 &&
            password1.value !== password2.value
        ) {

            event.preventDefault();

            password2.focus();

            passwordMatch.textContent =
                "✕ Passwords do not match";

            passwordMatch.className =
                "password-match error";

            return;

        }


        const button =
            document.getElementById("registerButton");


        if (button) {

            button.classList.add("loading");

            button.querySelector("span").textContent =
                "Creating account...";

        }

    });

}